const chatBox = document.getElementById('chat-box');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');

// Load messages from localStorage when the page loads
window.onload = function() {
    const savedMessages = JSON.parse(localStorage.getItem('chatMessages')) || [];
    savedMessages.forEach(message => {
        displayMessage(message.text, message.time);
    });
};

// Save message to localStorage
function saveMessages() {
    const messages = [];
    document.querySelectorAll('.message-container').forEach(container => {
        const messageText = container.querySelector('.message').textContent;
        const messageTime = container.querySelector('.timestamp').textContent;
        messages.push({ text: messageText, time: messageTime });
    });
    localStorage.setItem('chatMessages', JSON.stringify(messages));
}

// Display a message
function displayMessage(text, time) {
    const messageContainer = document.createElement('div');
    messageContainer.className = 'message-container';

    const messageElement = document.createElement('div');
    messageElement.className = 'message';
    messageElement.textContent = text;

    const timestamp = document.createElement('div');
    timestamp.className = 'timestamp';
    timestamp.textContent = time;

    messageContainer.appendChild(messageElement);
    messageContainer.appendChild(timestamp);

    chatBox.appendChild(messageContainer);
    chatBox.scrollTop = chatBox.scrollHeight; // Scroll to the bottom
}

sendButton.addEventListener('click', () => {
    const messageText = messageInput.value.trim();

    if (messageText) {
        const now = new Date();
        const messageTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        // Display the message
        displayMessage(messageText, messageTime);

        // Save messages to localStorage
        saveMessages();

        messageInput.value = '';
    }
});

messageInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        sendButton.click();
        e.preventDefault(); // Prevent default action
    }
});
import { getAuth } from "firebase/auth";

const auth = getAuth();
auth.languageCode = 'it';
// To apply the default browser preference instead of explicitly setting it.
// auth.useDeviceLanguage();
  import { getAuth, RecaptchaVerifier } from "firebase/auth";

const auth = getAuth();
window.recaptchaVerifier = new RecaptchaVerifier(auth, 'sign-in-button', {
  'size': 'invisible',
  'callback': (response) => {
    // reCAPTCHA solved, allow signInWithPhoneNumber.
    onSignInSubmit();
  }
});
