const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// MongoDB Connection (Make sure MongoDB is running or use a cloud service like MongoDB Atlas)
mongoose.connect('mongodb://localhost:27017/myapp', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => console.log('Connected to MongoDB'));

// Define a post schema
const postSchema = new mongoose.Schema({
  user: String,
  caption: String,
  image: String,
});

const Post = mongoose.model('Post', postSchema);

// Define an endpoint to submit a post
app.post('/submitPost', (req, res) => {
  const { user, caption, image } = req.body;

  const newPost = new Post({
    user,
    caption,
    image
  });

  newPost.save()
    .then(() => res.status(200).json({ message: 'Post submitted successfully!' }))
    .catch((err) => res.status(500).json({ message: 'Error submitting post', error: err }));
});

// Define an endpoint to get all posts
app.get('/getPosts', (req, res) => {
  Post.find()
    .then(posts => res.status(200).json(posts))
    .catch(err => res.status(500).json({ message: 'Error fetching posts', error: err }));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});